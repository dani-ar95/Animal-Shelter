package Shelter;

public interface IShel {

		double LEISHEXPENSES = 25.0;
		double RABIESVACCINE = 30.0;
		double SEDATEPDB = 8.0;
		double UNNEUTEREDTREAT = 10.0;
		
		double FIXEDAMOUNT = 1000.0;
		
		double FOODSMALL = 0.2;
		double FOODMEDIUM = 0.3;
}
